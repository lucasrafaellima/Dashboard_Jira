sub init()
    m.top.functionName = "buscar"
end sub

sub buscar()
    pedido = CreateObject("roUrlTransfer")
    porta = CreateObject("roMessagePort")
    pedido.setMessagePort(porta)
    pedido.setUrl(m.top.url)
    pedido.addHeader("Accept", "application/json")

    if not pedido.AsyncGetToString()
        m.top.erro = "não consegui iniciar a requisição"
        return
    end if

    msg = wait(15000, porta)
    if type(msg) <> "roUrlEvent"
        pedido.AsyncCancel()
        m.top.erro = "sem resposta em 15s"
        return
    end if

    codigo = msg.GetResponseCode()
    m.top.codigo = codigo
    if codigo <> 200
        ' o código negativo é erro de socket (não chegou a haver HTTP): é assim
        ' que "o firewall bloqueou" aparece na tela
        if codigo < 0
            m.top.erro = "rede: " + msg.GetFailureReason()
        else
            m.top.erro = "HTTP " + codigo.ToStr()
        end if
        return
    end if

    dados = ParseJson(msg.GetString())
    if dados = invalid
        m.top.erro = "a resposta não é JSON válido"
        return
    end if
    m.top.resultado = dados
end sub
