' Renderizador de primitivas — versão congelada (Fase 5).
'
' A cena é deliberadamente burra: não sabe o que é um KPI, uma barra ou uma
' tabela. Só sabe (1) buscar o índice de telas do servidor, (2) girar entre elas,
' e (3) desenhar retângulo, texto e imagem em coordenadas absolutas que já chegam
' resolvidas. É o que permite mudar o painel inteiro editando JavaScript no PC,
' sem reinstalar o canal — e reinstalar é caro, porque BrightScript não recarrega
' a quente. Depois desta fase, este arquivo não muda mais.
'
' Resistência (Fase 5): recarrega o índice de tempos em tempos (mudanças do
' servidor aparecem sozinhas), reconecta com backoff quando o servidor cai, e se
' recupera de base vazia sem intervenção — feito para ficar mês ligado numa TV.

sub init()
    m.palco = m.top.findNode("palco")
    m.recado = m.top.findNode("recado")
    m.rotador = m.top.findNode("rotador")
    m.atualizador = m.top.findNode("atualizador")
    m.religador = m.top.findNode("religador")
    m.rotador.observeField("fire", "aoRotacionar")
    m.atualizador.observeField("fire", "aoAtualizar")
    m.religador.observeField("fire", "aoReligar")

    m.fontes = {}      ' cache de nós Font por tamanho|negrito
    m.nos = []         ' nós desenhados, em paralelo às primitivas (para reuso)
    m.cache = {}       ' id da tela -> payload já buscado
    m.telas = []       ' [{ id, duracaoMs }] vindo do índice
    m.tarefas = []     ' Buscadores em voo (segura a referência contra o GC)
    m.i = 0
    m.pausado = false
    m.base = ""
    m.backoff = 0      ' ms da próxima tentativa de reconexão (0 = sem espera)

    m.top.setFocus(true)
    avisar("iniciando…")
end sub

sub aoConfigurar()
    cfg = m.top.configuracao
    if cfg = invalid or cfg.base = invalid or cfg.base = ""
        avisar("pkg:/config.json sem `base` — reempacote o canal")
        return
    end if
    m.base = cfg.base
    carregarIndice()
end sub

' ------------------------------------------------------------------ busca

sub carregarIndice()
    ' um carregamento em andamento cancela qualquer retry agendado
    m.religador.control = "stop"
    avisar("carregando índice…")
    novoBuscador(m.base + "/telas", "indice", "indice")
end sub

sub buscarTela(indice as integer, motivo as string)
    if indice < 0 or indice >= m.telas.count() then return
    id = m.telas[indice].id
    novoBuscador(m.base + "/tela/" + id, id, motivo)
end sub

function novoBuscador(url as string, alvo as string, motivo as string) as object
    b = CreateObject("roSGNode", "Buscador")
    b.alvo = alvo
    b.motivo = motivo
    b.url = url
    b.observeField("resultado", "aoReceber")
    b.observeField("erro", "aoFalhar")
    m.tarefas.push(b)
    b.control = "RUN"
    return b
end function

sub removerTarefa(tarefa as object)
    restantes = []
    for each t in m.tarefas
        if not t.isSameNode(tarefa) then restantes.push(t)
    end for
    m.tarefas = restantes
end sub

sub aoReceber(evt as object)
    tarefa = evt.getRoSGNode()
    if tarefa = invalid then return
    dados = tarefa.resultado
    motivo = tarefa.motivo
    alvo = tarefa.alvo
    removerTarefa(tarefa)

    if motivo = "indice"
        aplicarIndice(dados, false)
        return
    end if
    if motivo = "indice-silencioso"
        aplicarIndice(dados, true)
        return
    end if

    if dados <> invalid and dados.primitivas <> invalid then m.cache[alvo] = dados
    ' só pinta se esta ainda é a tela atual — o usuário pode ter trocado no meio
    if motivo = "mostrar" and m.telas.count() > 0 and m.telas[m.i].id = alvo
        m.backoff = 0            ' chegou dado: reconexão bem-sucedida
        m.religador.control = "stop"
        pintar(m.i)
    end if
end sub

sub aoFalhar(evt as object)
    tarefa = evt.getRoSGNode()
    if tarefa = invalid then return
    motivo = tarefa.motivo
    msg = tarefa.erro
    url = tarefa.url
    removerTarefa(tarefa)
    ' um prefetch que falhou não estraga a tela no ar; a atual continua girando
    if motivo = "prefetch" then return
    ' o refresh periódico é silencioso: se falhar, mantém a tela que está no ar
    ' (o próximo tique tenta de novo) em vez de piscar a tela de erro
    if motivo = "indice-silencioso" then return
    telaErro(msg, url)
    agendarReconexao()
end sub

' `silencioso`: refresh periódico (não pisca "carregando", preserva a tela atual)
' vs. carga inicial/reconexão (mostra progresso, começa da primeira tela).
sub aplicarIndice(dados as object, silencioso as boolean)
    if dados = invalid or dados.telas = invalid or dados.telas.count() = 0
        ' base vazia ou índice ruim: se for o refresh silencioso, ignora e segue;
        ' senão mostra erro e reagenda — quando os dados voltarem, se recupera
        if silencioso then return
        telaErro("índice sem telas", m.base + "/telas")
        agendarReconexao()
        return
    end if

    novas = []
    for each t in dados.telas
        novas.push({ id: t.id, duracaoMs: inteiro(t.duracaoMs) })
    end for
    m.telas = novas
    if m.i >= m.telas.count() then m.i = 0

    ajustarAtualizador(dados.atualizarEmMs)
    m.cache = {}                 ' força dados frescos em todas as telas
    m.backoff = 0
    m.religador.control = "stop"

    if not silencioso then avisar("carregando " + m.telas[m.i].id + "…")
    buscarTela(m.i, "mostrar")
end sub

' recarrega o índice periodicamente, sem piscar: é o que faz mudanças no
' servidor (nova tela, novos dados) aparecerem na TV sem ninguém tocar nela
sub aoAtualizar()
    novoBuscador(m.base + "/telas", "indice", "indice-silencioso")
end sub

sub ajustarAtualizador(ms as dynamic)
    d = inteiro(ms)
    ' piso de segurança: o índice não precisa (nem deve) recarregar toda hora
    if d < 15000 then d = 60000
    m.atualizador.control = "stop"
    m.atualizador.duration = d / 1000.0
    m.atualizador.control = "start"
end sub

' reconexão com backoff: 5s, 10s, 20s, teto de 30s. Enquanto o servidor estiver
' fora do ar, a tela de erro fica no ar e o canal segue tentando sozinho; quando
' voltar, o primeiro dado que chega zera o backoff (ver aoReceber/aplicarIndice)
sub agendarReconexao()
    if m.backoff = 0
        m.backoff = 5000
    else
        m.backoff = m.backoff * 2
        if m.backoff > 30000 then m.backoff = 30000
    end if
    m.religador.control = "stop"
    m.religador.duration = m.backoff / 1000.0
    m.religador.control = "start"
end sub

sub aoReligar()
    m.religador.control = "stop"
    carregarIndice()
end sub

' ------------------------------------------------------------------ rotação

sub aoRotacionar()
    if m.pausado then return
    irPara(proximoIndice())
end sub

function proximoIndice() as integer
    if m.telas.count() = 0 then return 0
    return (m.i + 1) mod m.telas.count()
end function

function anteriorIndice() as integer
    if m.telas.count() = 0 then return 0
    return (m.i + m.telas.count() - 1) mod m.telas.count()
end function

' troca para o índice: pinta do cache se houver, senão busca para mostrar
sub irPara(indice as integer)
    if m.telas.count() = 0 then return
    m.i = indice
    id = m.telas[indice].id
    if m.cache[id] <> invalid
        pintar(indice)
    else
        avisar("carregando " + id + "…")
        buscarTela(indice, "mostrar")
    end if
end sub

' desenha a tela (já em cache), rearma o relógio e faz prefetch da próxima
sub pintar(indice as integer)
    id = m.telas[indice].id
    dados = m.cache[id]
    if dados = invalid then return
    desenhar(dados.primitivas)
    if dados.rodape <> invalid then avisar(dados.rodape) else avisar("")
    armarRotador(indice)
    prox = proximoIndice()
    if prox <> indice and m.cache[m.telas[prox].id] = invalid
        buscarTela(prox, "prefetch")
    end if
end sub

sub armarRotador(indice as integer)
    dur = m.telas[indice].duracaoMs
    if dur <= 0 then dur = 8000
    m.rotador.control = "stop"
    m.rotador.duration = dur / 1000.0
    if not m.pausado then m.rotador.control = "start"
end sub

' ------------------------------------------------------------------ teclas

function onKeyEvent(tecla as string, apertada as boolean) as boolean
    if not apertada then return false

    if m.telas.count() = 0
        ' na tela de erro / antes do índice, OK e Replay tentam de novo agora
        if tecla = "OK" or tecla = "replay"
            m.backoff = 0
            carregarIndice()
            return true
        end if
        return false
    end if

    if tecla = "right"
        m.pausado = false
        irPara(proximoIndice())
        return true
    else if tecla = "left"
        m.pausado = false
        irPara(anteriorIndice())
        return true
    else if tecla = "OK"
        m.pausado = not m.pausado
        if m.pausado
            m.rotador.control = "stop"
            avisar("pausado — OK retoma · ← → trocam de tela")
        else
            armarRotador(m.i)
        end if
        return true
    else if tecla = "replay"
        m.backoff = 0
        carregarIndice()
        return true
    end if
    return false
end function

' ------------------------------------------------------------------ desenho

' Tela de erro própria: mostra o motivo e a URL tentada. O erro mais provável
' aqui não é o BrightScript — é o servidor fora do ar ou o firewall do PC —, por
' isso a URL aparece na cara.
sub telaErro(msg as string, url as string)
    m.rotador.control = "stop"
    p = []
    p.push({ t: "r", x: 0, y: 0, l: 1920, a: 1080, c: "#0F1621FF" })
    p.push({ t: "x", x: 96, y: 360, l: 1728, s: 80, c: "#FFFFFFFF", al: "center", b: true, v: "sem dados" })
    p.push({ t: "x", x: 96, y: 490, l: 1728, s: 40, c: "#9FB0C8FF", al: "center", v: msg })
    p.push({ t: "x", x: 96, y: 556, l: 1728, s: 28, c: "#9FB0C8FF", al: "center", v: url })
    p.push({ t: "x", x: 96, y: 660, l: 1728, s: 32, c: "#4472C4FF", al: "center", v: "OK ou Replay tenta de novo" })
    desenhar(p)
    avisar("")
end sub

' Reuso de nós preservando a ordem: m.nos é paralelo às primitivas. Reusa o nó
' do índice se o tipo (subtype) casar; ao primeiro que não casar, remove a cauda
' e recria dali em diante. Assim um refresh da MESMA tela não recria nó nenhum
' (evita o churn de apagar tudo a cada 8 s por 24 h), e a invariante "ordem do
' array = ordem de desenho" continua valendo — que um pool por tipo quebraria.
sub desenhar(primitivas as object)
    if primitivas = invalid then primitivas = []
    total = primitivas.count()

    for i = 0 to total - 1
        p = primitivas[i]
        alvo = tipoSG(p.t)
        no = m.nos[i]
        if no = invalid or no.subtype() <> alvo
            reduzirPara(i)
            no = CreateObject("roSGNode", alvo)
            m.palco.appendChild(no)
            m.nos.push(no)
        end if
        configurar(no, p)
        no.visible = true
    end for

    ' sobras: a tela nova é mais curta que a anterior
    reduzirPara(total)
end sub

' encolhe palco/m.nos até exatamente `n` nós
sub reduzirPara(n as integer)
    for j = m.nos.count() - 1 to n step -1
        m.palco.removeChildIndex(j)
        m.nos.delete(j)
    end for
end sub

sub configurar(no as object, p as object)
    tipo = p.t
    if tipo = "r"
        no.translation = [inteiro(p.x), inteiro(p.y)]
        no.width = inteiro(p.l)
        no.height = inteiro(p.a)
        no.color = cor(p.c, "0xFFFFFFFF")

    else if tipo = "x"
        no.translation = [inteiro(p.x), inteiro(p.y)]
        no.color = cor(p.c, "0xFFFFFFFF")
        no.text = textoDe(p.v)
        negrito = (p.b <> invalid and p.b = true)
        tamanho = inteiro(p.s)
        if tamanho <= 0 then tamanho = 28
        no.font = fonte(tamanho, negrito)
        if p.l <> invalid
            no.width = inteiro(p.l)
            ' o servidor já truncou o texto para caber; isto é só a rede de
            ' segurança para o caso de a métrica dele errar por pouco
            no.ellipsizeOnBoundary = true
        else
            no.width = 0
        end if
        if p.al <> invalid then no.horizAlign = p.al else no.horizAlign = "left"
        if p.n <> invalid and inteiro(p.n) > 1
            no.wrap = true
            no.maxLines = inteiro(p.n)
        else
            no.wrap = false
            no.maxLines = 0
        end if

    else if tipo = "i"
        no.translation = [inteiro(p.x), inteiro(p.y)]
        no.width = inteiro(p.l)
        no.height = inteiro(p.a)
        no.uri = textoDe(p.uri)
    end if
end sub

function tipoSG(t as string) as string
    if t = "r" then return "Rectangle"
    if t = "x" then return "Label"
    if t = "i" then return "Poster"
    return "Rectangle"
end function

sub avisar(texto as string)
    m.recado.font = fonte(26, false)
    m.recado.text = texto
end sub

' ------------------------------------------------------------------ utilidades

' Cor chega como "#RRGGBBAA" e o SceneGraph quer "0xRRGGBBAA".
function cor(texto, padrao as string) as string
    if texto = invalid then return padrao
    s = texto
    if Left(s, 1) = "#" then s = Mid(s, 2)
    if Len(s) = 6 then s = s + "FF"
    return "0x" + s
end function

' Tamanho arbitrário de fonte exige um nó Font: as fontes nomeadas têm tamanho
' fixo e pequeno demais para uma TV vista de longe. O cache evita recriar o nó a
' cada texto.
function fonte(tamanho as integer, negrito as boolean) as object
    chave = tamanho.ToStr() + "|" + negrito.ToStr()
    f = m.fontes[chave]
    if f = invalid
        f = CreateObject("roSGNode", "Font")
        if negrito
            f.uri = "font:BoldSystemFontFile"
        else
            f.uri = "font:SystemFontFile"
        end if
        f.size = tamanho
        m.fontes[chave] = f
    end if
    return f
end function

function textoDe(v) as string
    if v = invalid then return ""
    return v
end function

function inteiro(v) as integer
    if v = invalid then return 0
    return Int(v)
end function
