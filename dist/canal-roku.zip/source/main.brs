' Ponto de entrada do canal. Só sobe a cena e fica no laço de eventos —
' tudo o que interessa acontece em components/Painel.brs.
sub Main()
    tela = CreateObject("roSGScreen")
    porta = CreateObject("roMessagePort")
    tela.setMessagePort(porta)

    cena = tela.CreateScene("Painel")
    tela.show()

    ' O endereço do servidor não fica no código: o empacotador grava
    ' pkg:/config.json com o IP do PC no momento do build. Assim trocar de rede
    ' é reempacotar, não editar BrightScript.
    texto = ReadAsciiFile("pkg:/config.json")
    if texto <> ""
        cfg = ParseJson(texto)
        if cfg <> invalid then cena.configuracao = cfg
    end if

    while true
        msg = wait(0, porta)
        if type(msg) = "roSGScreenEvent"
            if msg.isScreenClosed() then return
        end if
    end while
end sub
